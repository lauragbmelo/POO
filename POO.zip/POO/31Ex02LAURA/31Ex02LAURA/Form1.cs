﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _31Ex02LAURA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTN_CALCULAR_Click(object sender, EventArgs e)
        {
            //VARIAVEIS

            int horas = int.Parse(TXT_HORAS.Text);
            int minutos = int.Parse(TXT_MINUTOS.Text);
            int segundos = int.Parse(TXT_SEGUNDOS.Text);

            int horas_segundos = 0;
            int minutos_segundos = 0;
            int segundos_total = 0;

            horas_segundos = horas * 3600;
            minutos_segundos = segundos * 60;

            segundos_total = minutos_segundos + horas_segundos + segundos;

            LBL_RESULTADO.Text = segundos_total.ToString("");
            
        }



    }
    }

