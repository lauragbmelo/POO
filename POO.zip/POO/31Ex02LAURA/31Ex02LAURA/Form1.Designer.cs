﻿namespace _31Ex02LAURA
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LBL_HORAS = new System.Windows.Forms.Label();
            this.LBL_SEGUNDOS = new System.Windows.Forms.Label();
            this.LBL_MINUTOS = new System.Windows.Forms.Label();
            this.TXT_HORAS = new System.Windows.Forms.TextBox();
            this.TXT_MINUTOS = new System.Windows.Forms.TextBox();
            this.TXT_SEGUNDOS = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTN_CALCULAR = new System.Windows.Forms.Button();
            this.LBL_RESULTADO = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LBL_HORAS
            // 
            this.LBL_HORAS.AutoSize = true;
            this.LBL_HORAS.Location = new System.Drawing.Point(0, 21);
            this.LBL_HORAS.Name = "LBL_HORAS";
            this.LBL_HORAS.Size = new System.Drawing.Size(38, 13);
            this.LBL_HORAS.TabIndex = 0;
            this.LBL_HORAS.Text = "Horas:";
            // 
            // LBL_SEGUNDOS
            // 
            this.LBL_SEGUNDOS.AutoSize = true;
            this.LBL_SEGUNDOS.Location = new System.Drawing.Point(0, 148);
            this.LBL_SEGUNDOS.Name = "LBL_SEGUNDOS";
            this.LBL_SEGUNDOS.Size = new System.Drawing.Size(58, 13);
            this.LBL_SEGUNDOS.TabIndex = 1;
            this.LBL_SEGUNDOS.Text = "Segundos:";
            // 
            // LBL_MINUTOS
            // 
            this.LBL_MINUTOS.AutoSize = true;
            this.LBL_MINUTOS.Location = new System.Drawing.Point(0, 87);
            this.LBL_MINUTOS.Name = "LBL_MINUTOS";
            this.LBL_MINUTOS.Size = new System.Drawing.Size(47, 13);
            this.LBL_MINUTOS.TabIndex = 2;
            this.LBL_MINUTOS.Text = "Minutos:";
            // 
            // TXT_HORAS
            // 
            this.TXT_HORAS.Location = new System.Drawing.Point(75, 18);
            this.TXT_HORAS.Name = "TXT_HORAS";
            this.TXT_HORAS.Size = new System.Drawing.Size(273, 20);
            this.TXT_HORAS.TabIndex = 3;
            // 
            // TXT_MINUTOS
            // 
            this.TXT_MINUTOS.Location = new System.Drawing.Point(75, 80);
            this.TXT_MINUTOS.Name = "TXT_MINUTOS";
            this.TXT_MINUTOS.Size = new System.Drawing.Size(148, 20);
            this.TXT_MINUTOS.TabIndex = 4;
            // 
            // TXT_SEGUNDOS
            // 
            this.TXT_SEGUNDOS.Location = new System.Drawing.Point(75, 145);
            this.TXT_SEGUNDOS.Name = "TXT_SEGUNDOS";
            this.TXT_SEGUNDOS.Size = new System.Drawing.Size(148, 20);
            this.TXT_SEGUNDOS.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(229, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // BTN_CALCULAR
            // 
            this.BTN_CALCULAR.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.BTN_CALCULAR.Location = new System.Drawing.Point(3, 186);
            this.BTN_CALCULAR.Name = "BTN_CALCULAR";
            this.BTN_CALCULAR.Size = new System.Drawing.Size(345, 37);
            this.BTN_CALCULAR.TabIndex = 7;
            this.BTN_CALCULAR.Text = "CALCULAR";
            this.BTN_CALCULAR.UseVisualStyleBackColor = false;
            this.BTN_CALCULAR.Click += new System.EventHandler(this.BTN_CALCULAR_Click);
            // 
            // LBL_RESULTADO
            // 
            this.LBL_RESULTADO.AutoSize = true;
            this.LBL_RESULTADO.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_RESULTADO.Location = new System.Drawing.Point(160, 237);
            this.LBL_RESULTADO.Name = "LBL_RESULTADO";
            this.LBL_RESULTADO.Size = new System.Drawing.Size(24, 25);
            this.LBL_RESULTADO.TabIndex = 8;
            this.LBL_RESULTADO.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 271);
            this.Controls.Add(this.LBL_RESULTADO);
            this.Controls.Add(this.BTN_CALCULAR);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.TXT_SEGUNDOS);
            this.Controls.Add(this.TXT_MINUTOS);
            this.Controls.Add(this.TXT_HORAS);
            this.Controls.Add(this.LBL_MINUTOS);
            this.Controls.Add(this.LBL_SEGUNDOS);
            this.Controls.Add(this.LBL_HORAS);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL_HORAS;
        private System.Windows.Forms.Label LBL_SEGUNDOS;
        private System.Windows.Forms.Label LBL_MINUTOS;
        private System.Windows.Forms.TextBox TXT_HORAS;
        private System.Windows.Forms.TextBox TXT_MINUTOS;
        private System.Windows.Forms.TextBox TXT_SEGUNDOS;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTN_CALCULAR;
        private System.Windows.Forms.Label LBL_RESULTADO;
    }
}

