﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _31EX05_LAURA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero = int.Parse(txt_num.Text);

            if (numero == 1) { LBL_MES.Text = "Janeiro"; }
            if (numero == 2) { LBL_MES.Text = "Fevereiro"; }
            if (numero == 3) { LBL_MES.Text = "Março"; }
            if (numero == 4) { LBL_MES.Text = "Abril"; }
            if (numero == 5) { LBL_MES.Text = "Maio"; }
            if (numero == 6) { LBL_MES.Text = "Junho"; }
            if (numero == 7) { LBL_MES.Text = "Julho"; }
            if (numero == 8) { LBL_MES.Text = "Agosto"; }
            if (numero == 9) { LBL_MES.Text = "Setembro"; }
            if (numero == 10) { LBL_MES.Text = "Outubro"; }
            if (numero == 11) { LBL_MES.Text = "Novembro"; }
            if (numero == 12) { LBL_MES.Text = "Dezembro"; }

            else if(numero > 12){
                MessageBox.Show("Digite apenas números entre 1 e 12!!!!");
            }




        }
    }
}
